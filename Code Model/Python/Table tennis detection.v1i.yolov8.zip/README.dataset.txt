# Table tennis detection > 2024-08-06 10:34am
https://universe.roboflow.com/0028_-huynh-long/table-tennis-detection-i3vbu

Provided by a Roboflow user
License: CC BY 4.0

